document.addEventListener("DOMContentLoaded", () => {
    // ---- PRELOADER ----
    const loader = document.querySelector('.loader-wrapper');
    setTimeout(() => {
        loader.style.opacity = '0';
        setTimeout(() => {
            loader.style.display = 'none';
        }, 1000);
    }, 2000);

    // ---- CUSTOM CURSOR ----
    const cursor = document.querySelector('.cursor');
    const follower = document.querySelector('.cursor-follower');
    
    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX + 'px';
        cursor.style.top = e.clientY + 'px';
        
        follower.style.left = e.clientX + 'px';
        follower.style.top = e.clientY + 'px';
    });

    const hoverElements = document.querySelectorAll('a, button, .menu-item, input, textarea');
    hoverElements.forEach(el => {
        el.addEventListener('mouseenter', () => cursor.classList.add('hover'));
        el.addEventListener('mouseleave', () => cursor.classList.remove('hover'));
    });

    // ---- NAVBAR SCROLL ----
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // ---- MOBILE MENU ----
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburger.classList.toggle('active');
    });
    
    document.querySelectorAll('.nav-links li a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
            hamburger.classList.remove('active');
        });
    });

    // ---- THREE.JS BACKGROUND HERO ----
    const canvas = document.getElementById('hero-3d-canvas');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    
    // Create floating particles / shapes (abstract "food" particles)
    const objects = [];
    const geometries = [
        new THREE.TorusGeometry(3, 1, 16, 50), // Donut shape
        new THREE.CylinderGeometry(2, 2, 0.5, 32), // Pancake shape
        new THREE.SphereGeometry(2, 32, 32) // Egg yolk shape
    ];
    
    const colors = [0xFFC107, 0xD32F2F, 0xF5E6D3]; // Primary diner colors
    
    for (let i = 0; i < 15; i++) {
        const geoIndex = Math.floor(Math.random() * geometries.length);
        const colorIndex = Math.floor(Math.random() * colors.length);
        
        const material = new THREE.MeshPhysicalMaterial({
            color: colors[colorIndex],
            metalness: 0.1,
            roughness: 0.5,
            clearcoat: 1.0,
            transparent: true,
            opacity: 0.8
        });
        
        const mesh = new THREE.Mesh(geometries[geoIndex], material);
        
        // Random positioning
        mesh.position.x = (Math.random() - 0.5) * 60;
        mesh.position.y = (Math.random() - 0.5) * 60;
        mesh.position.z = (Math.random() - 0.5) * 40 - 20;
        
        mesh.rotation.x = Math.random() * Math.PI;
        mesh.rotation.y = Math.random() * Math.PI;
        
        // Custom animation speeds
        mesh.userData = {
            rotSpeedX: (Math.random() - 0.5) * 0.02,
            rotSpeedY: (Math.random() - 0.5) * 0.02,
            floatSpeed: (Math.random() - 0.5) * 0.01,
            floatY: mesh.position.y
        };
        
        scene.add(mesh);
        objects.push(mesh);
    }
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    
    const pointLight = new THREE.PointLight(0xD32F2F, 2, 100);
    pointLight.position.set(10, 10, 10);
    scene.add(pointLight);
    
    const pointLight2 = new THREE.PointLight(0xFFC107, 1.5, 100);
    pointLight2.position.set(-10, -10, 10);
    scene.add(pointLight2);
    
    camera.position.z = 30;
    
    // Parallax on mouse move
    let mouseX = 0;
    let mouseY = 0;
    
    document.addEventListener('mousemove', (event) => {
        mouseX = (event.clientX / window.innerWidth) * 2 - 1;
        mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
    });
    
    let time = 0;
    function animate3D() {
        requestAnimationFrame(animate3D);
        time += 0.01;
        
        // Camera parallax interpolation
        camera.position.x += (mouseX * 5 - camera.position.x) * 0.05;
        camera.position.y += (mouseY * 5 - camera.position.y) * 0.05;
        camera.lookAt(scene.position);
        
        // Animate objects
        objects.forEach(obj => {
            obj.rotation.x += obj.userData.rotSpeedX;
            obj.rotation.y += obj.userData.rotSpeedY;
            obj.position.y = obj.userData.floatY + Math.sin(time + obj.userData.rotSpeedX * 1000) * 2;
        });
        
        renderer.render(scene, camera);
    }
    animate3D();
    
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // ---- GSAP ANIMATIONS ----
    gsap.registerPlugin(ScrollTrigger);
    
    // Hero Text Animation
    gsap.from(".gsap-hero", {
        y: 50,
        opacity: 0,
        duration: 1,
        stagger: 0.2,
        delay: 2.2,
        ease: "power3.out"
    });
    
    // Section Headers
    gsap.utils.toArray('.section-header').forEach(header => {
        gsap.from(header, {
            scrollTrigger: {
                trigger: header,
                start: "top 80%"
            },
            y: 30,
            opacity: 0,
            duration: 0.8
        });
    });

    // ---- MENU DATA & RENDERING ----
    const menuData = [
        // Eggs Your Way
        { cat: 'eggs-way', title: 'One Large Egg, Any Style', desc: 'Served with home fries, hash browns or grits, toast or biscuit and jelly', price: '$5.99', img: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=500&q=80' },
        { cat: 'eggs-way', title: 'Two Large Eggs, Any Style', desc: 'Served with home fries, hash browns or grits, toast or biscuit and jelly', price: '$6.99', img: 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=500&q=80' },
        { cat: 'eggs-way', title: 'Two Eggs With Bacon/Ham/Sausage', desc: 'Your choice of breakfast meat', price: '$8.99', img: 'https://images.unsplash.com/photo-1513442542250-854d436a73f2?w=500&q=80' },
        { cat: 'eggs-way', title: 'Two Eggs w/ Corned-Beef Hash', desc: 'Our signature corned-beef hash', price: '$9.99', img: 'https://images.unsplash.com/photo-1628246328905-f3ebec1b68ea?w=500&q=80' },
        
        // Combos
        { cat: 'combos', title: 'Steak And Eggs', desc: 'Juicy steak paired with two eggs your way', price: '$14.99', img: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=500&q=80' },
        { cat: 'combos', title: 'Texas Skillet', desc: 'Hearty skillet loaded with breakfast favorites', price: '$11.99', img: 'https://images.unsplash.com/photo-1590740698110-3375cb47eb79?w=500&q=80' },
        { cat: 'combos', title: 'Large Biscuits And Gravy', desc: 'Southern style buttermilk biscuits and sausage gravy', price: '$7.99', img: 'https://images.unsplash.com/photo-1627993073797-23832159fa62?w=500&q=80' },
        // Omelettes
        { cat: 'omelettes', title: 'Western Omelette', desc: 'Ham, onions, peppers, cheese', price: '$10.99', img: 'https://images.unsplash.com/photo-1510693206972-df098062cb71?w=500&q=80' },
        { cat: 'omelettes', title: 'Big Fat Greek Omelette', desc: 'Feta cheese, spinach, tomatoes, olives', price: '$11.99', img: 'https://images.unsplash.com/photo-1504113888839-1c8eb5023365?w=500&q=80' },
        
        // Pancakes
        { cat: 'pancakes', title: 'Three Fluffy Buttermilk Pancakes', desc: 'Classic golden pancakes with butter and syrup', price: '$7.99', img: 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=500&q=80' },
        { cat: 'pancakes', title: 'French Toast With Meat', desc: '3 slices with bacon or sausage', price: '$9.99', img: 'https://images.unsplash.com/photo-1484723091791-009ce034971e?w=500&q=80' }
    ];

    const menuGrid = document.getElementById('menu-grid');
    
    function renderMenu(filterCat) {
        menuGrid.innerHTML = '';
        const filtered = filterCat === 'all' ? menuData : menuData.filter(item => item.cat === filterCat);
        
        filtered.forEach((item, index) => {
            const el = document.createElement('div');
            el.className = 'menu-item';
            el.innerHTML = `
                <div class="menu-item-inner">
                    <div class="menu-img">
                        <img src="${item.img}" alt="${item.title}">
                    </div>
                    <div class="menu-content">
                        <div class="menu-title-price">
                            <h3>${item.title}</h3>
                            <span class="price">${item.price}</span>
                        </div>
                        <p class="menu-desc">${item.desc}</p>
                    </div>
                </div>
            `;
            menuGrid.appendChild(el);
            
            // Vanilla Tilt
            VanillaTilt.init(el, {
                max: 15,
                speed: 400,
                glare: true,
                "max-glare": 0.2,
                scale: 1.02
            });
            
            // Re-apply hover for cursor
            el.addEventListener('mouseenter', () => cursor.classList.add('hover'));
            el.addEventListener('mouseleave', () => cursor.classList.remove('hover'));
            
            // GSAP for items entering
            gsap.from(el, {
                scrollTrigger: { trigger: el, start: "top 90%" },
                y: 30, opacity: 0, duration: 0.5, delay: index * 0.1
            });
        });
    }
    
    renderMenu('all');
    
    document.querySelectorAll('.cat-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            renderMenu(e.target.dataset.filter);
        });
    });

    // ---- FORM GSAP ----
    gsap.utils.toArray('.form-gsap').forEach(form => {
        gsap.from(form, {
            scrollTrigger: { trigger: form, start: "top 80%" },
            y: 50, opacity: 0, duration: 1, ease: "power2.out"
        });
    });

    // ---- EMAILJS RESERVATION ----
    // Initialize EmailJS with your Public Key
    emailjs.init("-bkEPwt7E_y0No9b4");
    
    const bookingForm = document.getElementById('booking-form');
    const successMsg = document.getElementById('booking-success');
    
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const btn = bookingForm.querySelector('.btn-submit');
        const ogText = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
        btn.disabled = true;
        
        // Send the email using EmailJS
        emailjs.send("service_1gkqhb9", "template_retqorc", {
            name: document.getElementById('name').value,
            phone: document.getElementById('phone').value,
            email: document.getElementById('email').value,
            guests: document.getElementById('guests').value,
            date: document.getElementById('date').value,
            time: document.getElementById('time').value,
            message: document.getElementById('message').value,
            to_email: "vishvjeetyadav2013@gmail.com"
        }).then(() => {
            // Success
            bookingForm.style.display = 'none';
            successMsg.classList.remove('hidden');
        }).catch((error) => {
            // Error
            alert('Failed to send reservation. Please make sure you have added your Service ID and Template ID in the code.\n\nError: ' + (error.text || error.message || 'Unknown error'));
            console.error('EmailJS error:', error);
            btn.innerHTML = ogText;
            btn.disabled = false;
        });
    });

    // ---- REVIEWS SYSTEM ----
    let reviews = [
        { name: "Sarah M.", rating: 5, text: "Best homestyle breakfast I've had in Florida. The biscuits and gravy are out of this world! Highly recommend this cinematic experience.", date: "2 days ago" },
        { name: "David K.", rating: 4, text: "Great atmosphere, the eggs benedict was perfectly made. The diner feels nostalgic yet very modern.", date: "1 week ago" }
    ];
    
    const reviewsGrid = document.getElementById('reviews-grid');
    const reviewForm = document.getElementById('review-form');
    const stars = document.querySelectorAll('.star-rating i');
    const ratingInput = document.getElementById('review-rating');
    
    function renderReviews() {
        reviewsGrid.innerHTML = '';
        reviews.forEach((rev, index) => {
            let starsHtml = '';
            for(let i=0; i<5; i++) {
                starsHtml += i < rev.rating ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
            }
            
            const el = document.createElement('div');
            el.className = 'review-card glass-card';
            el.innerHTML = `
                <h4 class="reviewer-name">${rev.name}</h4>
                <div class="review-stars">${starsHtml}</div>
                <p class="review-text">"${rev.text}"</p>
                <small style="color:#666; margin-top:10px; display:block;">${rev.date}</small>
            `;
            reviewsGrid.appendChild(el);
            
            gsap.from(el, {
                scrollTrigger: { trigger: el, start: "top 85%" },
                x: -30, opacity: 0, duration: 0.6, delay: index * 0.2
            });
        });
    }
    
    renderReviews();
    
    // Star Hover Logic
    stars.forEach(star => {
        star.addEventListener('mouseover', function() {
            const val = this.dataset.rating;
            stars.forEach(s => {
                if(s.dataset.rating <= val) s.classList.add('hovered');
                else s.classList.remove('hovered');
            });
        });
        
        star.addEventListener('mouseout', function() {
            stars.forEach(s => s.classList.remove('hovered'));
        });
        
        star.addEventListener('click', function() {
            const val = this.dataset.rating;
            ratingInput.value = val;
            stars.forEach(s => {
                s.className = s.dataset.rating <= val ? 'fa-solid fa-star active' : 'fa-regular fa-star';
            });
        });
    });
    
    reviewForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const rating = ratingInput.value;
        if(rating == 0) {
            alert('Please select a star rating.');
            return;
        }
        
        const newReview = {
            name: document.getElementById('review-name').value,
            rating: parseInt(rating),
            text: document.getElementById('review-text').value,
            date: "Just now"
        };
        
        reviews.unshift(newReview);
        renderReviews();
        
        reviewForm.reset();
        ratingInput.value = 0;
        stars.forEach(s => s.className = 'fa-regular fa-star');
        alert('Thank you for your review!');
    });
});
